import React, { useState } from 'react'

function Login({ onLogin }) {
  return (
    <div style={{padding:40}}>
      <h2>Login</h2>
      <button onClick={onLogin}>Enter System</button>
    </div>
  )
}

export default function App() {
  const [logged, setLogged] = useState(false)
  const [page, setPage] = useState('dashboard')

  if (!logged) return <Login onLogin={() => setLogged(true)} />

  return (
    <div style={{padding:20}}>
      <h1>Full Shop System</h1>

      <nav style={{display:'flex', gap:10}}>
        <button onClick={()=>setPage('dashboard')}>Dashboard</button>
        <button onClick={()=>setPage('purchase')}>Purchase</button>
        <button onClick={()=>setPage('sales')}>Sales</button>
        <button onClick={()=>setPage('inventory')}>Inventory</button>
        <button onClick={()=>setPage('reports')}>Reports</button>
      </nav>

      <hr />

      {page === 'dashboard' && <h2>Dashboard</h2>}
      {page === 'purchase' && <h2>Purchase Module</h2>}
      {page === 'sales' && <h2>Sales Module</h2>}
      {page === 'inventory' && <h2>Inventory Module</h2>}
      {page === 'reports' && <h2>Reports Module</h2>}
    </div>
  )
}
